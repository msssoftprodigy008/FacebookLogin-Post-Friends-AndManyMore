package com.sromku.simple.fb.entities;

public interface User {

	String getId();

	String getName();
}
