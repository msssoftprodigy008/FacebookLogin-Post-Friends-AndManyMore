package com.sromku.simple.fb.listeners;

import com.sromku.simple.fb.entities.Album;

/**
 * On page request listener
 */
public abstract class OnAlbumListener extends OnActionListener<Album> {
}
