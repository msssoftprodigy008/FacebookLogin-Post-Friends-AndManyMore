package com.sromku.simple.fb.listeners;

import com.sromku.simple.fb.entities.Page;

/**
 * On page request listener
 */
public abstract class OnPageListener extends OnActionListener<Page> {
}
