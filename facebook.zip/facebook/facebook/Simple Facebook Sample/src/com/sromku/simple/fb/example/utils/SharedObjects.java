package com.sromku.simple.fb.example.utils;

import android.content.Context;

public class SharedObjects {

	public static Context context;
}
